﻿개발 도구 설치 가이드 모음 (PDF)
작성일: 2026-09-04 · Windows 11 기준

■ 설치 순서 (위에서부터 차례로)

  01_Node.js_설치가이드.pdf          Node.js + npm. 다른 CLI 도구의 전제 조건이므로 가장 먼저.
  02_Git_설치가이드.pdf              Git for Windows. 버전 관리 + gh CLI의 전제 조건.
  03_GitHub_CLI(gh)_설치가이드.pdf    gh. GitHub 로그인/저장소/PR을 터미널에서. (Git 필요)
  04_opencode_설치가이드.pdf          opencode + API 키 등록(Z.AI GLM / OpenAI). (Node.js 필요)

■ 함께 쓰는 도구

  05_VSCode_설치가이드.pdf            코드 편집기.
  06_클로드코드_설치법.pdf             Claude Code CLI. (PATH 등록 포함)
  07_Codex_CLI_설치.pdf              OpenAI Codex CLI. (Node.js 필요)
  08_안티그래비티_설치.pdf             Antigravity IDE.

■ 참고 자료

  참고_opencode-deepseek-설치가이드.pdf   DeepSeek 키로 opencode를 쓰는 경우
  참고_opencode-설치가이드.pdf            04번 문서의 원본 PDF

■ 메모

  - 모든 화면은 Windows 11에서 실제로 설치·실행하며 캡처한 것입니다.
    03번 gh는 winget 검색, gh --version, gh auth login 5단계, gh auth status 화면입니다.
  - CLI 도구를 설치한 직후에는 터미널을 새로 열어야 명령이 인식됩니다(PATH 갱신).
  - API 키는 외부에 공유하거나 git에 커밋하지 마세요.
